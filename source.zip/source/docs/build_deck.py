"""Builds docs/kafka-guide.pptx (editable PowerPoint). Run: python build_deck.py"""
import math
import re
from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Emu, Inches, Pt

NAVY = RGBColor(0x1C, 0x1F, 0x2B)
BRAND = RGBColor(0xFF, 0x5A, 0x5F)
ORANGE = RGBColor(0xFF, 0x8A, 0x3D)
INDIGO = RGBColor(0x63, 0x66, 0xF1)
GREEN = RGBColor(0x16, 0xB4, 0x7A)
SKY = RGBColor(0x0E, 0xA5, 0xE9)
TEXT = RGBColor(0x17, 0x1A, 0x23)
MUTED = RGBColor(0x6B, 0x72, 0x80)
SOFT = RGBColor(0xEE, 0xF0, 0xFA)
PEACH = RGBColor(0xFF, 0xF1, 0xE6)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
CODE_BG = RGBColor(0x1E, 0x22, 0x30)
CODE_FG = RGBColor(0xE6, 0xE9, 0xF2)
CODE_MUTE = RGBColor(0x7F, 0xD1, 0x9B)
GREY = RGBColor(0xD5, 0xD9, 0xE4)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]
state = {"n": 0, "section": ""}
warnings = []


# ---------------------------------------------------------------- helpers
def new_slide(bg=WHITE):
    s = prs.slides.add_slide(BLANK)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = bg
    state["n"] += 1
    return s


def runs(p, text, size, color=TEXT, bold=False, font="Calibri"):
    """Adds runs to a paragraph; **bold** and `code` segments are supported."""
    for part in re.split(r"(\*\*.+?\*\*|`.+?`)", text):
        if not part:
            continue
        r = p.add_run()
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            r.text, r.font.bold, r.font.name, r.font.color.rgb = part[2:-2], True, font, color
            r.font.size = Pt(size)
        elif part.startswith("`") and part.endswith("`") and len(part) > 2:
            r.text, r.font.bold, r.font.name = part[1:-1], bold, "Consolas"
            r.font.color.rgb = INDIGO if color == TEXT else color
            r.font.size = Pt(size - 1)
        else:
            r.text, r.font.bold, r.font.name, r.font.color.rgb = part, bold, font, color
            r.font.size = Pt(size)


def bullet(p, level_indent=0.22):
    pPr = p._p.get_or_add_pPr()
    pPr.set("marL", str(int(Inches(level_indent))))
    pPr.set("indent", str(-int(Inches(level_indent))))
    bu = etree.SubElement(pPr, qn("a:buChar"))
    bu.set("char", "•")


def clean(t):
    return re.sub(r"\*\*|`", "", t)


def fit_check(name, texts, size, width_in, height_in, charw=0.5, line=1.25, gap=4):
    chars_per_line = max(1, (width_in * 72) / (size * charw))
    lines = sum(max(1, math.ceil(len(clean(t)) / chars_per_line)) for t in texts)
    need = (lines * size * line + len(texts) * gap) / 72
    if need > height_in:
        warnings.append(f"slide {state['n']} {name}: needs ~{need:.1f}in, has {height_in:.1f}in")


def textbox(s, x, y, w, h, paras, size=16, color=TEXT, bold=False, align=PP_ALIGN.LEFT,
            anchor=MSO_ANCHOR.TOP, bullets=False, font="Calibri", gap=4, name="text"):
    tb = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(0.05)
    tf.margin_top = tf.margin_bottom = Inches(0.03)
    if isinstance(paras, str):
        paras = [paras]
    for i, t in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(gap)
        runs(p, t, size, color, bold, font)
        if bullets:
            bullet(p)
    fit_check(name, paras, size, w - 0.1 - (0.22 if bullets else 0), h, 0.55 if font == "Consolas" else 0.5, gap=gap)
    return tb


def rect(s, x, y, w, h, fill, line=None, shape=MSO_SHAPE.ROUNDED_RECTANGLE, radius=0.06):
    r = s.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    r.fill.solid()
    r.fill.fore_color.rgb = fill
    if line is None:
        r.line.fill.background()
    else:
        r.line.color.rgb = line
        r.line.width = Pt(1.25)
    r.shadow.inherit = False
    if shape == MSO_SHAPE.ROUNDED_RECTANGLE:
        r.adjustments[0] = radius
    return r


def box(s, x, y, w, h, text, fill=SOFT, color=TEXT, size=14, bold=True, line=None, sub=None):
    r = rect(s, x, y, w, h, fill, line)
    tf = r.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf.margin_left = tf.margin_right = Inches(0.06)
    tf.margin_top = tf.margin_bottom = Inches(0.03)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    runs(p, text, size, color, bold)
    if sub:
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        runs(p2, sub, max(size - 3, 9), color if color != TEXT else MUTED)
    fit_check("box:" + text[:18], [text] + ([sub] if sub else []), size, w - 0.12, h)
    return r


def arrow(s, x1, y1, x2, y2, color=MUTED, width=2):
    c = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    c.line.color.rgb = color
    c.line.width = Pt(width)
    ln = c.line._get_or_add_ln()
    tail = etree.SubElement(ln, qn("a:tailEnd"))
    tail.set("type", "triangle")
    return c


def header(s, title, section=None):
    section = section or state["section"]
    rect(s, 0, 0, 0.22, 7.5, BRAND, shape=MSO_SHAPE.RECTANGLE)
    textbox(s, 0.6, 0.3, 10.6, 0.75, title, size=28, bold=True, anchor=MSO_ANCHOR.MIDDLE, name="title")
    textbox(s, 9.3, 0.12, 3.8, 0.3, section.upper(), size=10, color=BRAND, bold=True, align=PP_ALIGN.RIGHT)
    rect(s, 0.65, 1.1, 1.2, 0.06, BRAND, shape=MSO_SHAPE.RECTANGLE)
    textbox(s, 0.6, 7.08, 8, 0.3, "Kafka Kitchen  |  Kafka theory, project code and interview guide", size=10, color=MUTED)
    textbox(s, 11.9, 7.08, 1.2, 0.3, str(state["n"]), size=10, color=MUTED, align=PP_ALIGN.RIGHT)


def title_slide(title, subtitle, tagline):
    s = new_slide(NAVY)
    rect(s, 0.9, 2.3, 1.4, 0.09, BRAND, shape=MSO_SHAPE.RECTANGLE)
    textbox(s, 0.85, 2.5, 11.5, 1.6, title, size=40, color=WHITE, bold=True, name="deck title")
    textbox(s, 0.85, 4.25, 11.5, 0.8, subtitle, size=22, color=ORANGE)
    textbox(s, 0.85, 5.4, 11.5, 0.9, tagline, size=15, color=GREY)


def section_slide(label, title, subtitle):
    state["section"] = title
    s = new_slide(NAVY)
    textbox(s, 0.9, 2.4, 11, 0.5, label.upper(), size=16, color=ORANGE, bold=True)
    textbox(s, 0.85, 2.9, 11.5, 1.2, title, size=44, color=WHITE, bold=True)
    textbox(s, 0.85, 4.2, 11.5, 1.0, subtitle, size=18, color=GREY)


def card(s, x, y, w, h, label, paras, fill=SOFT, label_color=BRAND, size=15, bullets=True, gap=5):
    rect(s, x, y, w, h, fill)
    textbox(s, x + 0.2, y + 0.1, w - 0.4, 0.3, label.upper(), size=11, color=label_color, bold=True)
    textbox(s, x + 0.2, y + 0.42, w - 0.4, h - 0.5, paras, size=size, bullets=bullets, gap=gap, name=label)


def concept(title, definition, points, project=None, note_label="In our project"):
    s = new_slide()
    header(s, title)
    rect(s, 0.6, 1.4, 12.1, 1.15, SOFT)
    textbox(s, 0.8, 1.48, 4, 0.3, "DEFINITION", size=11, color=BRAND, bold=True)
    textbox(s, 0.8, 1.76, 11.7, 0.8, definition, size=17, name="definition")
    if project:
        card(s, 0.6, 2.8, 7.2, 4.1, "Key points", points, fill=WHITE, size=16)
        card(s, 8.05, 2.8, 4.65, 4.1, note_label, project, fill=PEACH, label_color=ORANGE, size=15)
    else:
        card(s, 0.6, 2.8, 12.1, 4.1, "Key points", points, fill=WHITE, size=17)
    return s


def code_slide(title, code, steps, lang="JAVA", intro=None):
    s = new_slide()
    header(s, title)
    top = 1.4
    if intro:
        textbox(s, 0.6, 1.3, 12.1, 0.5, intro, size=15, color=MUTED, name="intro")
        top = 1.85
    h = 6.95 - top
    rect(s, 0.6, top, 7.75, h, CODE_BG)
    textbox(s, 0.8, top + 0.08, 2, 0.28, lang, size=10, color=ORANGE, bold=True)
    lines = code.strip("\n").split("\n")
    longest = max(len(l) for l in lines)
    code_size = 10.5
    for cand in (14, 13, 12, 11.5, 11, 10.5):
        if longest * cand * 0.55 / 72 <= 7.4 and len(lines) * cand * 1.22 / 72 <= h - 0.55:
            code_size = cand
            break
    tb = s.shapes.add_textbox(Inches(0.75), Inches(top + 0.38), Inches(7.5), Inches(h - 0.45))
    tf = tb.text_frame
    tf.word_wrap = False
    tf.margin_left = tf.margin_right = Inches(0.05)
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_after = Pt(0)
        stripped = line.strip()
        color = CODE_MUTE if stripped.startswith(("//", "#")) else CODE_FG
        runs(p, line.replace("`", "'") if line else " ", code_size, color, False, "Consolas")
    if longest * code_size * 0.55 / 72 > 7.5:
        warnings.append(f"slide {state['n']} code line too long ({longest} chars at {code_size}pt)")
    if len(lines) * code_size * 1.2 / 72 > h - 0.45:
        warnings.append(f"slide {state['n']} code too tall ({len(lines)} lines)")
    rect(s, 8.55, top, 4.2, h, PEACH)
    textbox(s, 8.75, top + 0.08, 3.8, 0.3, "HOW IT WORKS", size=11, color=ORANGE, bold=True)
    tb2 = s.shapes.add_textbox(Inches(8.75), Inches(top + 0.42), Inches(3.8), Inches(h - 0.5))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    tf2.margin_left = tf2.margin_right = Inches(0.05)
    step_size = 13
    for cand in (16, 15, 14, 13):
        est_chars = 3.7 * 72 / (cand * 0.5)
        est_lines = sum(max(1, math.ceil((len(clean(t)) + 5) / est_chars)) for t in steps)
        if (est_lines * cand * 1.25 + len(steps) * 9) / 72 <= h - 0.55:
            step_size = cand
            break
    for i, step in enumerate(steps):
        p = tf2.paragraphs[0] if i == 0 else tf2.add_paragraph()
        p.space_after = Pt(8)
        runs(p, f"({i + 1})  ", step_size, BRAND, True)
        runs(p, step, step_size)
    fit_check("steps", [f"(1) {t}" for t in steps], step_size, 3.7, h - 0.5, gap=8)
    return s


def table_slide(title, headers, rows, widths, note=None, size=13, top=1.5):
    s = new_slide()
    header(s, title)
    total = sum(widths)
    shape = s.shapes.add_table(len(rows) + 1, len(headers), Inches(0.6), Inches(top), Inches(total), Inches(0.4 * (len(rows) + 1)))
    tbl = shape.table
    for i, w in enumerate(widths):
        tbl.columns[i].width = Inches(w)
    for c, h in enumerate(headers):
        cell = tbl.cell(0, c)
        cell.fill.solid()
        cell.fill.fore_color.rgb = NAVY
        cell.text_frame.paragraphs[0].text = ""
        runs(cell.text_frame.paragraphs[0], h, size, WHITE, True)
    est = 0.45
    for r, row in enumerate(rows, start=1):
        row_lines = 1
        for c, value in enumerate(row):
            cell = tbl.cell(r, c)
            cell.fill.solid()
            cell.fill.fore_color.rgb = SOFT if r % 2 else WHITE
            cell.text_frame.word_wrap = True
            cell.text_frame.paragraphs[0].text = ""
            runs(cell.text_frame.paragraphs[0], value, size, TEXT)
            per_line = max(1, (widths[c] - 0.2) * 72 / (size * 0.5))
            row_lines = max(row_lines, math.ceil(len(re.sub(r"\*\*", "", value)) / per_line))
        est += max(0.4, row_lines * size * 1.25 / 72 + 0.15)
    avail = (6.95 - top) - (0.9 if note else 0)
    if est > avail:
        warnings.append(f"slide {state['n']} table ~{est:.1f}in > {avail:.1f}in")
    if note:
        rect(s, 0.6, 6.05, total, 0.8, PEACH)
        textbox(s, 0.8, 6.1, total - 0.4, 0.7, note, size=14, anchor=MSO_ANCHOR.MIDDLE, name="note")
    return s


def flow(s, items, y, h=1.0, x0=0.6, total_w=12.1, gap=0.45, size=13):
    n = len(items)
    w = (total_w - gap * (n - 1)) / n
    for i, it in enumerate(items):
        text, fill, color = it[0], it[1], it[2]
        sub = it[3] if len(it) > 3 else None
        x = x0 + i * (w + gap)
        box(s, x, y, w, h, text, fill, color, size=size, sub=sub)
        if i < n - 1:
            arrow(s, x + w + 0.04, y + h / 2, x + w + gap - 0.04, y + h / 2)


def qa_slide(title, qas):
    s = new_slide()
    header(s, title)
    y = 1.4
    h = 1.78
    for q, a in qas:
        rect(s, 0.6, y, 12.1, h - 0.1, SOFT)
        textbox(s, 0.8, y + 0.07, 11.7, 0.4, q, size=18, color=BRAND, bold=True, name="question")
        textbox(s, 0.8, y + 0.52, 11.7, h - 0.7, a, size=16, name="answer")
        y += h
    return s


# ================================================================ DECK
title_slide("Apache Kafka: Theory, Project Code and Interview Guide",
            "Explained with the Kafka Kitchen project: Spring Boot on a 3-broker cluster",
            "Part 1 Theory  |  Part 2 Project code walkthrough  |  Part 3 Operations  |  Part 4 Interview Q&A")

s = new_slide()
header(s, "How this guide is organised", "Introduction")
table_slide.__doc__  # keep linters quiet
rows = [
    ["1", "Kafka theory", "What each Kafka concept is, why it exists, and where it appears in our project"],
    ["2", "Project walkthrough", "Real code from Kafka Kitchen, shown next to a step-by-step explanation"],
    ["3", "Operations", "How to run the 3 brokers, verify them, troubleshoot, and known limits"],
    ["4", "Interview Q&A", "50 questions with answers: fundamentals, producers, consumers, replication, design"],
]
shape = s.shapes.add_table(5, 3, Inches(0.6), Inches(1.6), Inches(12.1), Inches(2.6))
t = shape.table
for i, w in enumerate([0.9, 3.0, 8.2]):
    t.columns[i].width = Inches(w)
for c, h in enumerate(["Part", "Topic", "What you get"]):
    cell = t.cell(0, c)
    cell.fill.solid()
    cell.fill.fore_color.rgb = NAVY
    cell.text_frame.paragraphs[0].text = ""
    runs(cell.text_frame.paragraphs[0], h, 14, WHITE, True)
for r, row in enumerate(rows, 1):
    for c, v in enumerate(row):
        cell = t.cell(r, c)
        cell.fill.solid()
        cell.fill.fore_color.rgb = SOFT if r % 2 else WHITE
        cell.text_frame.paragraphs[0].text = ""
        runs(cell.text_frame.paragraphs[0], v, 15, TEXT, c == 1)
card(s, 0.6, 4.6, 12.1, 2.2, "How to read each slide type", [
    "**Theory slides**: a definition, the key points, and an orange box showing where the idea appears in our project",
    "**Code slides**: the code on the left with numbered markers; the numbered steps on the right explain each marker",
    "**Q&A slides**: each question has its answer directly beneath it",
], fill=WHITE, size=15)

# ------------------------------------------------------------ PART 1
section_slide("Part 1", "Kafka theory", "Concepts, definitions and the reasons behind them")

concept("What is Kafka?",
        "Apache Kafka is a distributed, durable, replicated commit log for streams of events. Producers append events and consumers read them at their own pace.",
        ["Events are **stored** for a retention period; reading does not delete them",
         "Many independent consumers can read the same data, and can **replay** it",
         "Data is spread over **partitions** and copied across **brokers** for scale and safety",
         "Typical uses: messaging between services, event-driven systems, log and metrics pipelines, stream processing, change data capture"],
        ["Order and status events flow between the **restaurant**, **notification** and **API** parts of the app",
         "Services are decoupled: the API does not call the restaurant directly",
         "Every event is kept, so a failed message can be retried or inspected"])

table_slide("Kafka vs. a traditional message queue",
            ["", "Traditional queue", "Kafka"],
            [["After a message is read", "Removed", "Kept until retention expires"],
             ["Replay old messages", "Not possible", "Re-read from any offset"],
             ["Several consumers", "Compete for each message", "Each consumer group reads everything"],
             ["Scaling", "Limited by the queue", "Partitions spread load across brokers"],
             ["Ordering", "Per queue", "Per partition"],
             ["Delivery model", "Broker pushes", "Consumer pulls at its own pace"]],
            [3.4, 4.0, 4.7],
            note="Rule of thumb: choose Kafka when you need high throughput, replay, or many independent readers of the same events.")

table_slide("Core building blocks",
            ["Term", "Meaning", "In our project"],
            [["Broker", "A Kafka server that stores partitions and serves clients", "3 brokers: 9092, 9094, 9096"],
             ["Controller", "Tracks metadata and elects partition leaders", "Same 3 nodes (KRaft)"],
             ["Topic", "A named stream of messages", "food-orders, food-order-status"],
             ["Partition", "An ordered, append-only slice of a topic", "3 per topic"],
             ["Offset", "A message's position in its partition", "Tracked per consumer group"],
             ["Replica", "A copy of a partition on a broker", "3 per partition"],
             ["Producer / Consumer", "Writes / reads messages", "FoodEventProducer / listeners"],
             ["Consumer group", "Consumers sharing a topic's partitions", "restaurant-service, notification-service"]],
            [2.4, 5.3, 4.4], size=13)

s = new_slide()
header(s, "Architecture at a glance", "Part 1: Theory")
box(s, 0.6, 2.3, 2.6, 1.3, "Producers", INDIGO, WHITE, 18, sub="send events")
rect(s, 4.1, 1.5, 4.9, 4.4, SOFT)
textbox(s, 4.3, 1.55, 4.5, 0.35, "KAFKA CLUSTER (KRaft)", size=12, color=BRAND, bold=True)
for i, name in enumerate(["Broker 1", "Broker 2", "Broker 3"]):
    box(s, 4.4 + i * 1.5, 2.2, 1.35, 1.1, name, WHITE, TEXT, 13, line=GREY, sub="partitions")
box(s, 4.4, 3.7, 4.3, 1.0, "Topics → partitions → replicas", WHITE, TEXT, 14, line=GREY)
box(s, 4.4, 4.9, 4.3, 0.8, "Controllers keep metadata", NAVY, WHITE, 13)
box(s, 9.9, 1.9, 2.8, 1.3, "Consumer group A", GREEN, WHITE, 16, sub="each partition → one consumer")
box(s, 9.9, 3.8, 2.8, 1.3, "Consumer group B", GREEN, WHITE, 16, sub="also reads every message")
arrow(s, 3.25, 2.95, 4.05, 2.95)
arrow(s, 9.05, 2.55, 9.85, 2.55)
arrow(s, 9.05, 4.4, 9.85, 4.4)
textbox(s, 0.6, 6.1, 12.1, 0.8,
        ["A client needs only **one reachable broker** (the bootstrap server): it returns the full cluster layout, so clients then talk directly to each partition's leader."],
        size=15, name="arch note")

concept("Topics, partitions and offsets",
        "A topic is split into partitions. Each partition is an ordered, append-only log, and every message in it has a sequential number called its offset.",
        ["Messages are only ever **appended**; offsets never change",
         "Order is guaranteed **only within one partition**",
         "Partitions are the unit of **parallelism**: more partitions allow more consumers",
         "Partitions of one topic are spread across brokers, so the load is shared"],
        ["Each of our 4 topics has **3 partitions**",
         "`concurrency: 3` runs one consumer thread per partition",
         "You can increase partitions later but never reduce them"])

s = new_slide()
header(s, "Partitions and offsets, drawn", "Part 1: Theory")
for row, (name, n) in enumerate([("Partition 0", 6), ("Partition 1", 4), ("Partition 2", 5)]):
    y = 1.7 + row * 1.35
    textbox(s, 0.6, y + 0.2, 1.8, 0.5, name, size=16, bold=True)
    for i in range(n):
        box(s, 2.5 + i * 1.0, y, 0.85, 0.85, str(i), SOFT, TEXT, 18, line=GREY)
    box(s, 2.5 + n * 1.0, y, 1.3, 0.85, "next write", WHITE, BRAND, 12, line=BRAND)
card(s, 0.6, 5.85, 12.1, 1.05, "Reading the diagram", [
    "Each row is an independent ordered log. New messages go to the end. Consumers remember the offset they have reached, per partition."],
    fill=PEACH, label_color=ORANGE, size=15, bullets=False)

concept("Message keys and ordering",
        "A message may carry a key. The producer hashes the key to pick the partition, so all messages with the same key land in the same partition and stay in order.",
        ["Partition = hash(key) mod number of partitions (murmur2 hash)",
         "No key: batches are spread across partitions, so there is no per-entity order",
         "Increasing the partition count **changes the mapping** for new messages of a key",
         "A hot key can overload one partition"],
        ["Key = **orderId** for both topics",
         "So `PLACED`, `RECEIVED`, `PREPARING`, `OUT_FOR_DELIVERY` and `DELIVERED` for one order are read in sequence",
         "Different orders are processed in parallel on different partitions"])

concept("How Kafka stores data (and why it is fast)",
        "Each partition is a directory of segment files on disk. Kafka appends to the active segment and removes or compacts old segments according to the topic's cleanup policy.",
        ["Files per segment: `.log` (data), `.index` (offsets), `.timeindex` (timestamps)",
         "**Sequential writes** and reads are fast on disks, and the OS page cache serves recent data",
         "**Batching and compression** reduce network and disk work",
         "**Zero-copy** transfer (`sendfile`) sends data from cache to the network without copying through the application",
         "Defaults: `retention.ms` 7 days, `segment.bytes` 1 GB"],
        ["Topic data lives under each node's `log.dirs`, for example `D:/kafka-cluster-data/node-1`",
         "Order topics keep data 7 days; dead letter topics 30 days"])

s = new_slide()
header(s, "Producer: the path of one message", "Part 1: Theory")
flow(s, [("1. Serialize", INDIGO, WHITE, "key + value → bytes"),
         ("2. Partition", INDIGO, WHITE, "hash(key) → partition"),
         ("3. Batch", INDIGO, WHITE, "linger.ms, batch.size, compress"),
         ("4. Send", INDIGO, WHITE, "to the partition leader"),
         ("5. Acknowledge", GREEN, WHITE, "per acks; retry on error")],
     1.7, h=1.4, size=15)
card(s, 0.6, 3.5, 6.0, 3.4, "What each step does", [
    "**Serialize**: our value serializer turns the event into JSON bytes",
    "**Partition**: same key, same partition, so order is kept",
    "**Batch**: records for one partition are grouped and compressed (`lz4`)",
    "**Send**: the leader appends the batch and replicas copy it",
    "**Acknowledge**: the future completes when `acks` is satisfied"], fill=WHITE, size=14)
card(s, 6.85, 3.5, 5.85, 3.4, "In our project", [
    "`acks: all`, `lz4` compression, `linger.ms: 5`",
    "`delivery.timeout.ms: 10000` caps total send time including retries",
    "`FoodEventProducer` waits on the future, so failures reach the caller as HTTP 503"],
     fill=PEACH, label_color=ORANGE, size=14)

table_slide("Producer reliability settings",
            ["Setting", "Effect", "Our value"],
            [["acks=0", "No confirmation: fastest, can lose data", "not used"],
             ["acks=1", "Leader wrote it: data lost if the leader dies before copying", "not used"],
             ["acks=all", "Every in-sync replica wrote it", "**all**"],
             ["enable.idempotence", "Broker discards duplicate retries (default since Kafka 3.0)", "**true**"],
             ["max.in.flight.requests", "Keep ≤ 5 so retries preserve order", "default"],
             ["delivery.timeout.ms", "Upper bound on one send, including retries", "10000"],
             ["linger.ms / batch.size", "Trade a little latency for throughput", "5 ms"]],
            [3.2, 6.1, 2.8],
            note="Idempotence removes duplicates caused by producer retries. It does not remove duplicates caused by your own logic or consumer redelivery.")

concept("Replication: leaders and followers",
        "Each partition is copied to several brokers. One copy is the leader that handles reads and writes; the others are followers that fetch from the leader.",
        ["**Replication factor** = total copies, including the leader",
         "If a leader's broker fails, a follower from the in-sync set becomes the new leader",
         "Leaders are spread over brokers to balance the load",
         "Consumers can optionally fetch from the closest follower (Kafka 2.4+)"],
        ["Replication factor **3** on every topic: one copy on each broker",
         "Any one broker can fail without losing data or stopping writes"])

s = new_slide()
header(s, "Replica layout across 3 brokers", "Part 1: Theory")
for c, name in enumerate(["Broker 1", "Broker 2", "Broker 3"]):
    box(s, 2.6 + c * 2.7, 1.5, 2.5, 0.6, name, NAVY, WHITE, 15)
layout = [["Leader", "Follower", "Follower"], ["Follower", "Leader", "Follower"], ["Follower", "Follower", "Leader"]]
for r in range(3):
    textbox(s, 0.6, 2.35 + r * 1.0, 1.9, 0.6, f"Partition {r}", size=16, bold=True, anchor=MSO_ANCHOR.MIDDLE)
    for c in range(3):
        lead = layout[r][c] == "Leader"
        box(s, 2.6 + c * 2.7, 2.3 + r * 1.0, 2.5, 0.8, layout[r][c], BRAND if lead else SOFT, WHITE if lead else TEXT, 15)
card(s, 0.6, 5.5, 12.1, 1.4, "Why this layout", [
    "Each broker leads one partition and follows the other two, so reads and writes are balanced. Exact placement is chosen by Kafka; this is the typical result."],
    fill=PEACH, label_color=ORANGE, size=15, bullets=False)

concept("In-sync replicas, high watermark and leader epoch",
        "The ISR is the set of replicas fully caught up with the leader. The high watermark is the highest offset copied to the whole ISR, and consumers only see data up to it.",
        ["A follower leaves the ISR if it falls behind for longer than `replica.lag.time.max.ms` (30 s)",
         "A message is **committed** once all current ISR members have it",
         "The **leader epoch** is a counter that prevents replicas diverging after a failover",
         "`min.insync.replicas` is the smallest ISR size that still accepts `acks=all` writes"],
        ["`min.insync.replicas=2` with 3 replicas",
         "With 2 brokers up the ISR is 2: writes continue",
         "With 1 broker up the ISR is 1: writes are **rejected** and the API returns 503"])

concept("The durability formula",
        "No acknowledged message is lost when the producer, topic and brokers are all configured for safety together. Each setting closes a different gap.",
        ["`acks=all`: wait for every in-sync replica",
         "`replication.factor ≥ 3`: survive a broker failure",
         "`min.insync.replicas = 2`: never accept a write that exists on only one broker",
         "`unclean.leader.election.enable=false`: never promote an out-of-date replica",
         "Consumers **commit offsets only after** processing"],
        ["All four broker and producer settings are set in this project",
         "Trade-off: when too many brokers fail, the system chooses to **stop accepting writes** instead of risking data loss"],
        note_label="Trade-off we chose")

concept("KRaft: Kafka without ZooKeeper",
        "KRaft stores cluster metadata in an internal Kafka log managed by the Raft consensus protocol. A quorum of controller nodes elects an active controller.",
        ["A majority of controller voters must be alive; 3 voters tolerate 1 failure, 5 tolerate 2",
         "Simpler operations: one system to run, faster failover, more partitions per cluster",
         "A node can be a **broker**, a **controller**, or both",
         "Every node is formatted once with the same **cluster ID** before its first start"],
        ["Each of our 3 nodes is **broker + controller**",
         "`controller.quorum.voters` lists all three controller ports (9093, 9095, 9097)",
         "`format-cluster.bat` writes the cluster ID once; `start-cluster.bat` starts the nodes"])

s = new_slide()
header(s, "Consumers and consumer groups", "Part 1: Theory")
textbox(s, 0.6, 1.4, 2.5, 0.35, "TOPIC PARTITIONS", size=11, color=BRAND, bold=True)
rect(s, 4.2, 1.35, 4.2, 3.45, SOFT)
textbox(s, 4.4, 1.4, 3.8, 0.3, "GROUP: restaurant-service", size=11, color=BRAND, bold=True)
for i in range(3):
    y = 1.9 + i * 0.95
    box(s, 0.6, y, 2.0, 0.7, f"Partition {i}", NAVY, WHITE, 14)
    box(s, 5.0, y, 2.6, 0.7, f"Consumer {i + 1}", GREEN, WHITE, 14)
    arrow(s, 2.65, y + 0.35, 4.95, y + 0.35)
box(s, 9.1, 1.9, 3.6, 1.2, "GROUP: notification-service", INDIGO, WHITE, 14, sub="independently reads all messages")
arrow(s, 2.65, 2.25, 9.05, 2.4, color=INDIGO)
card(s, 0.6, 5.0, 12.1, 1.9, "Rules", [
    "Inside one group, **each partition is read by exactly one consumer**; extra consumers stay idle",
    "Different groups are independent: every group receives **all** messages",
    "Progress is committed per group in the internal `__consumer_offsets` topic"], fill=WHITE, size=15)

table_slide("Rebalancing and partition assignors",
            ["Trigger", "Why it happens"],
            [["Consumer joins or leaves", "Group membership changed"],
             ["Heartbeat missed", "`session.timeout.ms` exceeded: consumer presumed dead"],
             ["Slow processing", "`max.poll.interval.ms` exceeded between polls"],
             ["Partition count changes", "More partitions to distribute"]],
            [4.0, 8.1], top=1.5, size=14,
            note="Assignors: Range and RoundRobin pause everyone during a rebalance. Sticky keeps old assignments. CooperativeSticky (used here) moves only the partitions that must move.")

concept("Offsets and commits",
        "A committed offset records the next message a group should read for a partition. After a restart, the group resumes from its committed offset.",
        ["**Commit after processing** gives at-least-once delivery",
         "Committing before processing risks losing messages if the consumer crashes",
         "`auto.offset.reset` (`earliest` or `latest`) applies only when the group has **no** committed offset",
         "**Consumer lag** = latest offset minus committed offset: the key health metric"],
        ["`auto-offset-reset: earliest`: a new group starts from the oldest message",
         "Spring commits after the listener method returns successfully",
         "If the listener throws, the message is retried, then dead-lettered"])

table_slide("Delivery semantics",
            ["Semantics", "How it is achieved", "Risk"],
            [["At-most-once", "Commit first, then process", "Message can be lost"],
             ["**At-least-once**", "Process, then commit", "Message can be processed twice"],
             ["Exactly-once", "Idempotent producer + transactions + `read_committed` consumers", "More complexity; applies to Kafka-to-Kafka flows"]],
            [3.0, 5.7, 3.4],
            note="Our project is at-least-once. That is why handlers are idempotent: processing the same event twice must be harmless. Writing to external systems needs idempotent writes or an outbox.")

concept("Retention and compaction",
        "Retention decides how long Kafka keeps messages. Delete policy removes old segments; compact policy keeps only the latest value for each key.",
        ["Delete: by age (`retention.ms`) or size (`retention.bytes`)",
         "Compact: latest value per key is kept; a **tombstone** (null value) deletes a key",
         "Compaction suits state and changelog topics, such as the latest profile per user",
         "Deleting happens per segment, not per message"],
        ["Delete policy on all topics",
         "`retention-ms`: 7 days for orders and status",
         "`dlt-retention-ms`: 30 days so failures can be investigated and replayed"])

table_slide("Security, ecosystem and monitoring",
            ["Area", "What it covers"],
            [["Encryption", "TLS between clients and brokers, and between brokers"],
             ["Authentication", "SASL: PLAIN, SCRAM, OAUTHBEARER, or mutual TLS"],
             ["Authorization", "ACLs per user, topic, group and operation"],
             ["Kafka Connect / Streams", "Move data in and out / process streams inside your app"],
             ["Schema Registry", "Manage Avro, Protobuf or JSON schemas and compatibility"],
             ["What to monitor", "Consumer lag, under-replicated partitions, ISR changes, request latency, dead letter volume"]],
            [3.4, 8.7],
            note="Our prod profile enables SASL_SSL with credentials from environment variables, and exposes health, metrics and Prometheus endpoints.")

# ------------------------------------------------------------ PART 2
section_slide("Part 2", "The Kafka Kitchen project", "What it does, how the pieces connect, and the code explained step by step")

concept("What the project does",
        "Kafka Kitchen is a food ordering app. Customers place orders, the restaurant must confirm each one, and the customer confirms delivery. Services communicate only through Kafka topics.",
        ["Customer places an order: published to topic **food-orders**",
         "Restaurant is alerted by a popup and **accepts** the order",
         "Status changes are published to **food-order-status**",
         "The notification service pushes live updates to browsers",
         "When the food is on the way, the **customer confirms receipt** to mark it delivered",
         "Messages that keep failing go to `<topic>-dlt`"],
        ["Spring Boot 3.5, Java 21, spring-kafka",
         "3-broker KRaft cluster, replication factor 3",
         "In-memory order store (no database yet)"],
        note_label="Technology")

s = new_slide()
header(s, "Order lifecycle", "Part 2: Project")
flow(s, [("PLACED", SOFT, TEXT, "customer orders"),
         ("RECEIVED", INDIGO, WHITE, "restaurant accepts"),
         ("PREPARING", ORANGE, WHITE, "kitchen cooking"),
         ("OUT_FOR_DELIVERY", SKY, WHITE, "sent out"),
         ("DELIVERED", GREEN, WHITE, "customer confirms")],
     1.8, h=1.3, size=14)
card(s, 0.6, 3.5, 12.1, 3.4, "Rules enforced by the code", [
    "Status can only **move forward**; an old or duplicate event is ignored",
    "The restaurant's status endpoint **rejects DELIVERED**: only the customer can set it",
    "`confirm-delivery` checks the customer name (403) and that the order is out for delivery (409)",
    "Every transition is a Kafka event keyed by `orderId`, so each order stays in sequence"],
     fill=WHITE, size=16)

s = new_slide()
header(s, "Event flow through Kafka", "Part 2: Project")
flow(s, [("Customer browser", SOFT, TEXT, "POST /orders"),
         ("API + producer", INDIGO, WHITE, "publishes event"),
         ("food-orders", NAVY, WHITE, "topic"),
         ("RestaurantListener", GREEN, WHITE, "group restaurant-service"),
         ("Kitchen popup", ORANGE, WHITE, "via SSE")],
     1.5, h=1.2, size=12)
flow(s, [("Kitchen clicks Accept", SOFT, TEXT, "POST /status"),
         ("API + producer", INDIGO, WHITE, "publishes event"),
         ("food-order-status", NAVY, WHITE, "topic"),
         ("NotificationListener", GREEN, WHITE, "group notification-service"),
         ("Customer browser", ORANGE, WHITE, "live update (SSE)")],
     3.2, h=1.2, size=12)
card(s, 0.6, 4.85, 12.1, 2.05, "Also", [
    "Customer taps **I received it**: `POST /confirm-delivery` publishes `DELIVERED` to food-order-status",
    "A failing message is retried 3 times, then published to **food-orders-dlt** or **food-order-status-dlt**"],
     fill=PEACH, label_color=ORANGE, size=15)

table_slide("Topics in this project",
            ["Topic", "Published by", "Read by", "Settings"],
            [["food-orders", "FoodEventProducer.orderPlaced()", "RestaurantListener (restaurant-service)", "3 partitions, RF 3, min ISR 2, 7 days"],
             ["food-order-status", "FoodEventProducer.statusChanged()", "NotificationListener (notification-service)", "3 partitions, RF 3, min ISR 2, 7 days"],
             ["food-orders-dlt", "Error handler", "Nobody (investigation, replay)", "3 partitions, RF 3, 30 days"],
             ["food-order-status-dlt", "Error handler", "Nobody", "3 partitions, RF 3, 30 days"]],
            [2.6, 3.3, 3.4, 2.8], size=12,
            note="Four topics created by the app, 12 partitions in total, each with 3 replicas. Kafka also keeps internal topics such as __consumer_offsets.")

s = new_slide()
header(s, "The 3-broker cluster", "Part 2: Project")
box(s, 3.9, 1.4, 5.5, 0.9, "Spring Boot app", INDIGO, WHITE, 18, sub="bootstrap-servers: 9092, 9094, 9096")
rect(s, 0.9, 3.0, 11.5, 2.5, SOFT)
textbox(s, 1.1, 3.05, 6, 0.3, "KRAFT CLUSTER: 3 NODES, EACH BROKER + CONTROLLER", size=11, color=BRAND, bold=True)
for i, (port, ctl) in enumerate([(9092, 9093), (9094, 9095), (9096, 9097)]):
    box(s, 1.3 + i * 3.7, 3.5, 3.3, 1.7, f"Broker {i + 1}", NAVY, WHITE, 18, sub=f"clients :{port}   controller :{ctl}")
    arrow(s, 5.2 + (i - 1) * 1.0, 2.35, 2.95 + i * 3.7, 3.45, color=INDIGO)
card(s, 0.9, 5.7, 11.5, 1.2, "Behaviour", [
    "Brokers replicate to each other; controllers vote on metadata. Any one node can fail without losing data or availability."],
    fill=PEACH, label_color=ORANGE, size=15, bullets=False)

code_slide("Broker configuration: node-1.properties",
"""process.roles=broker,controller                  # (1)
node.id=1                                        # (1)
controller.quorum.voters=1@localhost:9093,2@localhost:9095,3@localhost:9097  # (2)
listeners=PLAINTEXT://localhost:9092,CONTROLLER://localhost:9093             # (3)
advertised.listeners=PLAINTEXT://localhost:9092  # (3)
controller.listener.names=CONTROLLER
inter.broker.listener.name=PLAINTEXT
log.dirs=D:/kafka-cluster-data/node-1            # (4)
default.replication.factor=3                     # (5)
min.insync.replicas=2                            # (5)
offsets.topic.replication.factor=3               # (6)
auto.create.topics.enable=false                  # (7)
unclean.leader.election.enable=false             # (8)""",
["**Role and identity**: this node is both broker and controller, with ID 1",
 "**Quorum**: the three controller voters on their controller ports; a majority of 2 is needed",
 "**Listeners**: clients use 9092; `advertised.listeners` is the address clients are told to use",
 "**Data folder**: holds `meta.properties` and all partition data for this node",
 "**Durability defaults**: 3 copies, at least 2 in sync for `acks=all` writes",
 "**Consumer progress** topic is also replicated 3 times",
 "A typo in a topic name must **not** create a topic silently",
 "An out-of-date replica is **never** promoted to leader"], lang="PROPERTIES")

concept("What a broker checks at startup",
        "At startup a node works out who it is, what job it has, who else is in the cluster, and how it serves traffic, in that order.",
        ["**1. Identity**: reads `meta.properties` (cluster ID, node ID) and matches `node.id`; missing file means the node was never formatted",
         "**2. Role**: broker, controller, or both, from `process.roles`",
         "**3. Quorum**: contacts the other voters and joins the controller election",
         "**4. Listeners**: opens its ports and registers with the controller",
         "**5. Partitions**: loads data from `log.dirs`; followers catch up and rejoin the ISR"],
        ["`meta.properties` is written **once** by the format step, never at startup",
         "A wrong cluster ID or node ID makes the node refuse to start, which protects your data",
         "Error `No readable meta.properties files found` means: run `format-cluster.bat` first"])

code_slide("Connection and topic settings: application.yml",
"""app:
  kafka:
    partitions: 3                            # (1)
    replication-factor: 3                    # (2)
    min-insync-replicas: 2                   # (2)
    create-topics: true                      # (3)
    retention-ms: 604800000                  # (4)  7 days
    dlt-retention-ms: 2592000000             # (4)  30 days
    send-timeout-ms: 15000                   # (5)
spring:
  kafka:
    bootstrap-servers: localhost:9092,localhost:9094,localhost:9096   # (6)""",
["**Partitions** per topic: the maximum consumer parallelism",
 "**Copies and minimum in-sync copies**, matching the broker settings",
 "Whether the app creates topics; set false when infrastructure provisions them",
 "How long messages are kept: 7 days normal, 30 days dead letter",
 "How long an API call waits for the broker's acknowledgement before failing with 503",
 "All three brokers are listed; one reachable broker is enough to start. The real file wraps this in `${KAFKA_BOOTSTRAP_SERVERS:...}` so an environment variable can override it"],
 lang="YAML")

code_slide("Creating the topics: KafkaConfig",
"""@Bean
@ConditionalOnProperty(name = "app.kafka.create-topics",
        havingValue = "true", matchIfMissing = true)   // (1)
public KafkaAdmin.NewTopics topics(...) {              // (2)
    return new KafkaAdmin.NewTopics(
        topic(foodOrders, retentionMs),
        topic(dltName(foodOrders), dltRetentionMs),
        topic(foodOrderStatus, retentionMs),
        topic(dltName(foodOrderStatus), dltRetentionMs));
}

private NewTopic topic(String name, long retention) {  // (3)
    return TopicBuilder.name(name)
        .partitions(partitions)
        .replicas(replicationFactor)
        .config(MIN_IN_SYNC_REPLICAS_CONFIG, minInsyncReplicas)
        .config(RETENTION_MS_CONFIG, retention)
        .build();
}""",
["The bean exists only when `app.kafka.create-topics` is true (the default)",
 "`NewTopics` groups four `NewTopic` objects in one bean: two main topics and their `-dlt` topics",
 "Each topic gets partitions, replication factor, min ISR and retention (values are passed as strings in the real code)",
 "At startup `KafkaAdmin` creates **missing** topics. It does **not** change existing ones",
 "`NewTopic` describes one topic; `NewTopics` is just Spring's convenient wrapper"])

code_slide("Producer: acknowledged publishing",
"""private void send(String topic, String key, Object event) {
    try {
        var result = kafkaTemplate.send(topic, key, event)  // (1)
                .get(sendTimeoutMs, TimeUnit.MILLISECONDS); // (2)
        log.debug("Sent to {}-{}@{}", topic,
                result.getRecordMetadata().partition(),
                result.getRecordMetadata().offset());       // (3)
    } catch (ExecutionException | TimeoutException e) {
        throw new EventPublishException(                    // (4)
                "Could not publish to " + topic, e);
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw new EventPublishException("Interrupted", e);
    }
}""",
["`send(topic, key, event)`: the key is `orderId`, so one order stays in one partition",
 "`.get(...)` **waits for the broker acknowledgement**, up to `send-timeout-ms`",
 "The result tells us which partition and offset the message landed on",
 "On failure or timeout we throw `EventPublishException`, mapped to **HTTP 503**. The API never says accepted for an event Kafka lost",
 "Before this change, failures were only logged and the API still returned 202"])

code_slide("Producer and consumer properties",
"""spring.kafka:
  producer:
    acks: all                                       # (1)
    compression-type: lz4                           # (2)
    properties:
      enable.idempotence: true                      # (3)
      linger.ms: 5                                  # (4)
      delivery.timeout.ms: 10000                    # (5)
  consumer:
    auto-offset-reset: earliest                     # (6)
    value-deserializer: ErrorHandlingDeserializer   # (7)
    properties:
      allow.auto.create.topics: false               # (8)
      partition.assignment.strategy: CooperativeStickyAssignor  # (9)
  listener:
    concurrency: 3                                  # (10)""",
["Wait for **all** in-sync replicas",
 "Compress batches to save network and disk",
 "Retries cannot create duplicates",
 "Wait up to 5 ms to fill batches",
 "Total time cap for one send, including retries",
 "A new group starts from the oldest message",
 "A malformed message becomes an error the handler can route to the DLT",
 "Consumers cannot create topics by mistake",
 "Rebalances move only the partitions that must move",
 "3 consumer threads per listener: one per partition"], lang="YAML")

code_slide("Consumer: RestaurantListener",
"""@KafkaListener(topics = "${app.topics.food-orders}",
               groupId = "restaurant-service")           // (1)
public void onOrderPlaced(FoodOrderPlaced order) {       // (2)
    FoodOrderView view = FoodOrderView.from(order);
    if (store.saveNew(view)) {                           // (3)
        hub.publish(view,
            "Waiting for the restaurant to confirm your order"); // (4)
    }
}""",
["Subscribes to `food-orders` as group `restaurant-service`. This group sees **every** order",
 "Kafka delivers the deserialized JSON as a `FoodOrderPlaced` object",
 "`saveNew` returns **false** if the order already exists, which happens when Kafka redelivers after a failure",
 "Only a new order alerts the kitchen (through the SSE hub), so a redelivered message cannot alert twice",
 "The restaurant then **accepts** through the UI; the accept action publishes the next event"])

code_slide("Idempotent handling: FoodOrderStore",
"""public boolean saveNew(FoodOrderView order) {
    return orders.putIfAbsent(order.orderId(), order) == null;  // (1)
}

public Optional<FoodOrderView> advance(String orderId,
        FoodOrderStatus status, Instant at) {
    AtomicReference<FoodOrderView> changed = new AtomicReference<>();
    orders.computeIfPresent(orderId, (id, current) -> {
        if (status.compareTo(current.status()) <= 0) {          // (2)
            return current;                                     // (3)
        }
        FoodOrderView updated = current.withStatus(status, at);
        changed.set(updated);                                   // (4)
        return updated;
    });
    return Optional.ofNullable(changed.get());
}""",
["`putIfAbsent`: a redelivered \"placed\" event cannot overwrite an order that has already progressed",
 "Compare the incoming status with the stored one. Statuses are ordered, so the check is a simple comparison",
 "An old or duplicate event is **ignored**: the order stays as it is",
 "Only a real forward move produces a notification",
 "This is what makes **at-least-once delivery safe**: handling the same event twice has the same result as once"])

code_slide("Retries and the dead letter topic",
"""ExponentialBackOffWithMaxRetries backOff =
        new ExponentialBackOffWithMaxRetries(3);           // (1)
backOff.setInitialInterval(1000L);
backOff.setMultiplier(2.0);
backOff.setMaxInterval(10_000L);

DefaultErrorHandler handler = new DefaultErrorHandler(
    (record, ex) -> {
        log.error("Moving record to DLT: topic={} offset={}",
                record.topic(), record.offset(), ex);     // (2)
        meterRegistry.counter("app.kafka.dlt.published",
                "topic", record.topic()).increment();     // (3)
        recoverer.accept(record, ex);                     // (4)
    }, backOff);
handler.addNotRetryableExceptions(
        IllegalArgumentException.class);                  // (5)""",
["Three retries with exponential delay: 1 s, 2 s, 4 s (capped at 10 s)",
 "When retries are exhausted we log the failing record with its topic, partition and offset",
 "A counter metric makes dead letter volume visible to monitoring and alerts",
 "The recoverer publishes the record to the dead letter topic, so the partition keeps moving",
 "Some errors are pointless to retry; these go straight to the DLT"])

code_slide("Routing to the DLT and handling poison messages",
"""Map<Class<?>, KafkaOperations<?, ?>> templates = new LinkedHashMap<>();
templates.put(byte[].class,
        new KafkaTemplate<>(dltBytesProducerFactory));    // (1)
templates.put(Object.class, kafkaTemplate);               // (2)

DeadLetterPublishingRecoverer recoverer =
    new DeadLetterPublishingRecoverer(templates,
        (record, ex) -> new TopicPartition(
                dltName(record.topic()), -1));            // (3)
recoverer.setFailIfSendResultIsError(true);               // (4)""",
["A malformed message fails deserialization, so the record value is **raw bytes**; the JSON serializer cannot write bytes, so a separate `byte[]` template is used",
 "Normal objects are republished with the regular JSON template. The order matters: `byte[]` is checked first",
 "Destination is `<topic>-dlt`, the name we created. Partition `-1` lets the **key** pick it, so the DLT need not match the source partition count",
 "If publishing to the DLT itself fails, the failure is reported instead of silently dropping the message",
 "The bytes template is **not** a Spring bean: a second `KafkaTemplate` bean would switch off Boot's auto-configured one"])

code_slide("Customer confirms delivery: controller",
"""@PostMapping("/orders/{orderId}/confirm-delivery")
public ResponseEntity<Void> confirmDelivery(
        @PathVariable String orderId,
        @RequestParam String customer) {
    FoodOrderView order = store.find(orderId)
        .orElseThrow(() -> new ResponseStatusException(NOT_FOUND)); // (1)
    if (!order.customerName().equalsIgnoreCase(customer.trim())) {
        throw new ResponseStatusException(FORBIDDEN);               // (2)
    }
    if (order.status() != FoodOrderStatus.OUT_FOR_DELIVERY) {
        throw new ResponseStatusException(CONFLICT);                // (3)
    }
    producer.statusChanged(orderId, order.customerName(),
            FoodOrderStatus.DELIVERED);                             // (4)
    return ResponseEntity.accepted().build();
}""",
["The order must exist (404 otherwise)",
 "Only the customer who placed it can confirm (403). There is no login yet, so this checks the name only",
 "It must currently be out for delivery (409 otherwise)",
 "A `DELIVERED` event is published to `food-order-status`; the notification service then updates everyone's screens",
 "The restaurant's own status endpoint **rejects** `DELIVERED`, so receipt can only come from the customer"])

code_slide("Live updates: NotificationHub (SSE)",
"""private final ExecutorService sender =
    Executors.newSingleThreadExecutor(...);              // (1)

public void publish(FoodOrderView order, String message) {
    sender.execute(() -> subscribers.stream()
        .filter(s -> s.wants(order))                     // (2)
        .forEach(s -> send(s, event)));
}

private void send(Subscriber s, SseEventBuilder event) {
    try {
        s.emitter().send(event);                         // (3)
    } catch (IOException | IllegalStateException ex) {
        subscribers.remove(s);                           // (4)
    }
}""",
["One sender thread keeps events in order and stops a slow browser from blocking Kafka listener threads",
 "A customer tab receives only its own orders; the restaurant tab (no customer filter) receives all",
 "Each event is pushed over a Server-Sent Events connection",
 "If the browser has gone, the container has already ended the connection. We only drop the subscriber. Calling `completeWithError` here threw again and killed the sender thread (the earlier bug)"])

table_slide("How the cluster behaves when brokers fail",
            ["Brokers up", "What happens", "In the app"],
            [["3", "Normal operation", "Orders accepted"],
             ["2", "New leaders are elected from the ISR; ISR size is 2, which meets min ISR", "Orders still accepted"],
             ["1", "ISR size 1 is below min ISR 2, so writes are rejected", "API returns **503**; UI shows Try again"],
             ["0", "Cluster unavailable", "Publishing times out, then 503"]],
            [1.8, 6.2, 4.1], size=14,
            note="Because unclean leader election is off, the cluster prefers to stop accepting writes rather than lose acknowledged messages. Start the brokers again and it recovers.")

# ------------------------------------------------------------ PART 3
section_slide("Part 3", "Operations and troubleshooting", "Run it, verify it, and fix common problems")

code_slide("Run and verify the cluster",
"""REM 1. Once only: same cluster ID for all 3 nodes
format-cluster.bat

REM 2. Start the 3 brokers (3 windows)
start-cluster.bat

REM 3. Start the app
java -jar target\\kafka-order-system-0.0.1-SNAPSHOT.jar

REM 4. Verify replication
kafka-topics.bat --bootstrap-server localhost:9092 --describe""",
["Formats each node's `log.dirs` with one shared cluster ID. Never run it again on nodes that already hold data",
 "Starts the three broker windows. Close one window to simulate a broker failure",
 "The app connects to all three brokers and creates the four topics",
 "Expect `ReplicationFactor: 3` and **three entries in Isr** for each partition. Stop one broker and place an order: it works. Stop two: you get 503"],
 lang="BATCH")

table_slide("Troubleshooting",
            ["Symptom", "Cause", "Fix"],
            [["No readable meta.properties files found", "Storage not formatted", "Run format-cluster.bat once"],
             ["Topic creation fails", "Fewer than 3 brokers for replication factor 3", "Start all three brokers"],
             ["503 on orders", "ISR below 2 or brokers unreachable", "Restart the stopped brokers"],
             ["Connects, then times out", "Wrong advertised.listeners", "Use an address the app can reach"],
             ["Messages in -dlt topics", "Retries exhausted or non-retryable error", "Inspect headers, fix, replay"],
             ["Brokers will not form a cluster", "Nodes formatted with different cluster IDs", "Delete the data folder and format again"]],
            [4.0, 4.4, 3.7], size=13)

concept("Known limits and next steps",
        "The Kafka part is built to be safe and highly available. The surrounding application is still a learning project, with these gaps.",
        ["All three brokers run on one machine: shows the behaviour, but no protection from hardware failure",
         "Orders live in memory: a restart loses them, and two app instances would not share state",
         "No transactional outbox: saving an order and publishing its event are not atomic (needs a database)",
         "No API authentication; delivery confirmation checks only the customer name"],
        ["Add a database and an **outbox** pattern",
         "Add authentication and per-customer authorization",
         "Run brokers on separate machines or zones (`broker.rack`)",
         "Add alerts on consumer lag and dead letter volume"],
        note_label="Next steps")

# ------------------------------------------------------------ PART 4
section_slide("Part 4", "Interview questions and answers", "50 questions: fundamentals, producers, replication, consumers, delivery, architecture, Spring Kafka")

QA = [
 ("What is Kafka?", "A distributed, replicated commit log for event streams. Producers append events, consumers read them, and data is retained for a configured time so it can be replayed."),
 ("Kafka vs. RabbitMQ?", "Kafka keeps messages after reading, allows replay, scales through partitions and suits high-throughput streams. RabbitMQ removes messages once consumed and offers richer routing."),
 ("Why is Kafka fast?", "Sequential disk I/O, OS page cache, batching and compression, zero-copy transfer to consumers, and parallelism through partitions."),
 ("What is a topic and a partition?", "A topic is a named stream. It is split into ordered, append-only partitions, which are the unit of parallelism and distribution."),
 ("Is message order guaranteed?", "Only within a partition. Use a key so related events land in the same partition."),
 ("What is an offset?", "A message's sequential position within a partition. Consumers track it per consumer group."),
 ("What does a broker do?", "Stores partitions and serves produce and fetch requests from clients and replication requests from other brokers."),
 ("How does a client find the cluster?", "Through bootstrap.servers. One reachable broker returns the full metadata, including which broker leads each partition."),
 ("Does Kafka push or pull?", "Consumers pull. They control their own pace and there is natural backpressure."),
 ("How is a partition chosen for a message?", "With a key: hash (murmur2) of the key modulo the partition count. Without a key, batches are spread across partitions."),
 ("Explain acks.", "0: no confirmation. 1: the leader wrote it. all: every in-sync replica wrote it, which is the safe choice."),
 ("What do linger.ms and batch.size do?", "They let the producer wait briefly to gather more records per request, trading a little latency for higher throughput."),
 ("What does enable.idempotence do?", "Gives the producer an ID and sequence numbers so broker-side retries cannot create duplicates. It does not remove duplicates from your own business logic."),
 ("How can retries break ordering?", "With several in-flight requests, a failed batch may be retried after a later one succeeded. Idempotence with max.in.flight at most 5 preserves order."),
 ("What is delivery.timeout.ms?", "The maximum total time for a send, including retries. After that the send future fails."),
 ("Leader, follower and ISR?", "Clients use the leader; followers copy it; the ISR is the set of replicas caught up with the leader."),
 ("What is the high watermark?", "The highest offset replicated to the whole ISR. Consumers only see messages up to it, so they never read data that could be lost."),
 ("When does a replica leave the ISR?", "When it has not caught up with the leader within replica.lag.time.max.ms (default 30 seconds)."),
 ("min.insync.replicas with acks=all?", "If the ISR is smaller than the minimum, writes are rejected. Replication factor 3 with min ISR 2 tolerates one broker failure."),
 ("Why not set min ISR equal to the replication factor?", "Then a single broker failure would block all writes, so you lose availability for little extra safety."),
 ("What is unclean leader election?", "Promoting an out-of-sync replica when no in-sync one is available. It improves availability but can lose acknowledged data, so keep it off for durability."),
 ("What is a consumer group?", "Consumers sharing a topic's partitions. Each partition goes to one consumer in the group, and every group receives all messages."),
 ("What if there are more consumers than partitions?", "The extra consumers sit idle, because a partition is read by only one consumer per group."),
 ("What triggers a rebalance?", "A consumer joining or leaving, a missed heartbeat (session.timeout.ms), exceeding max.poll.interval.ms, or a change in partition count."),
 ("How do you reduce rebalance impact?", "Use the cooperative sticky assignor, static membership (group.instance.id), and keep processing time below max.poll.interval.ms."),
 ("Where are consumer offsets stored?", "In the internal topic __consumer_offsets, replicated like any other topic."),
 ("What does auto.offset.reset do?", "It sets where a group starts when it has no committed offset: earliest (oldest message) or latest (only new ones)."),
 ("Auto vs. manual offset commit?", "Auto commit can commit before processing finishes and lose messages. Committing after processing gives at-least-once delivery."),
 ("What is consumer lag?", "Latest offset minus the group's committed offset per partition. Rising lag means consumers are falling behind."),
 ("How do you scale consumption?", "Add consumers up to the partition count. Beyond that, add partitions or make processing faster."),
 ("At-most-once, at-least-once, exactly-once?", "Messages may be lost; may be duplicated; neither. At-least-once is the usual default and needs idempotent handlers."),
 ("How does Kafka provide exactly-once?", "An idempotent producer, transactions, and consumers using read_committed. It covers read-process-write inside Kafka."),
 ("Exactly-once with a database?", "Make writes idempotent (unique IDs, upserts) or use a transactional outbox, because a database write and a Kafka commit are not atomic."),
 ("How do you avoid losing messages end to end?", "acks=all, replication factor 3 or more, min ISR 2, unclean election off, idempotent producer, and commit offsets only after processing."),
 ("What if a consumer crashes mid-processing?", "Its offset was not committed, so the message is delivered again. Handlers must be idempotent."),
 ("What is a poison message?", "A message that always fails processing. Use limited retries and a dead letter topic, and wrap deserialization so bad bytes do not crash the listener."),
 ("KRaft vs. ZooKeeper?", "KRaft stores metadata in Kafka using the Raft protocol, removing ZooKeeper. Operations are simpler and failover is faster."),
 ("What is the controller?", "The node that manages cluster metadata and partition leader election. In KRaft the active controller is elected by a Raft quorum."),
 ("What does a 3-voter quorum tolerate?", "One failure. A majority (2 of 3) must be alive to keep making metadata decisions."),
 ("What is the cluster ID for?", "It identifies the cluster. Each node stores it in meta.properties when formatted, and nodes with a different ID refuse to join."),
 ("Retention vs. compaction?", "Retention deletes data by age or size. Compaction keeps the latest value per key; a null value (tombstone) deletes the key."),
 ("Can you change the partition count?", "You can only increase it, and that changes the key-to-partition mapping for new messages of the same key."),
 ("How many partitions should a topic have?", "Enough for the target throughput and consumer parallelism. More partitions add overhead and slow failover, so do not over-provision."),
 ("What is rack awareness?", "broker.rack lets Kafka spread replicas across racks or zones so one rack failing does not remove every copy."),
 ("Can consumers read from followers?", "Yes, since Kafka 2.4: fetching from the closest replica reduces cross-zone network traffic."),
 ("KafkaTemplate vs. @KafkaListener?", "KafkaTemplate sends messages. @KafkaListener declares a consumer method; concurrency sets consumer threads per partition."),
 ("How are failures handled in Spring Kafka?", "A DefaultErrorHandler with a back-off retries the record, then a DeadLetterPublishingRecoverer sends it to a dead letter topic."),
 ("Why use ErrorHandlingDeserializer?", "A deserialization failure otherwise throws before your handler and loops forever. The wrapper turns it into an error the error handler can route to the DLT."),
 ("Why does this project wait on the send future?", "Otherwise a failed publish is invisible to the caller and the API would return 202 for a lost order. Now it returns 503."),
 ("Why does the DLT use partition -1?", "A negative partition lets the record key choose the partition, so the DLT does not need the same partition count as the source topic."),
]
assert len(QA) == 50, len(QA)
groups = [("Fundamentals", 0, 9), ("Producers", 9, 15), ("Replication", 15, 21), ("Consumers", 21, 30),
          ("Delivery guarantees", 30, 36), ("Architecture", 36, 45), ("Spring Kafka and this project", 45, 50)]
for gname, lo, hi in groups:
    chunk = QA[lo:hi]
    for k in range(0, len(chunk), 3):
        part = chunk[k:k + 3]
        first, last = lo + k + 1, lo + k + len(part)
        qa_slide(f"{gname} ({first}-{last})", [(f"{lo + k + i + 1}. {q}", a) for i, (q, a) in enumerate(part)])

concept("Key takeaways",
        "Kafka is a replicated log: partitions give scale, replicas give durability, and consumer groups give independent, parallel readers.",
        ["Durability = `acks=all` + replication factor 3 + min ISR 2 + no unclean election",
         "Order holds **per partition**: use a key such as `orderId`",
         "Delivery is **at-least-once**: make handlers idempotent",
         "Handle failures with **retries, backoff and a dead letter topic**",
         "Monitor **consumer lag, under-replicated partitions and DLT volume**"],
        ["Kafka Kitchen applies each of these ideas",
         "Next: database, outbox, authentication, multi-host cluster"],
        note_label="Where to go next")

s = new_slide(NAVY)
textbox(s, 0.85, 3.0, 11.5, 1.2, "Questions?", size=48, color=WHITE, bold=True)
textbox(s, 0.85, 4.3, 11.5, 0.8, "Source: docs/build_deck.py regenerates this deck", size=16, color=GREY)

out = "kafka-guide.pptx"
prs.save(out)
print(f"saved {out}: {state['n']} slides")
for w in warnings:
    print("WARN", w)
