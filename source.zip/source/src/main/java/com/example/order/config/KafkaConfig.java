package com.example.order.config;

import io.micrometer.core.instrument.MeterRegistry;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.TopicConfig;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaOperations;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.ExponentialBackOffWithMaxRetries;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class KafkaConfig implements DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(KafkaConfig.class);

    private ProducerFactory<String, Object> dltBytesProducerFactory;

    private final int partitions;
    private final int replicationFactor;
    private final int minInsyncReplicas;
    private final long retentionMs;
    private final long dltRetentionMs;

    public KafkaConfig(@Value("${app.kafka.partitions}") int partitions,
                       @Value("${app.kafka.replication-factor}") int replicationFactor,
                       @Value("${app.kafka.min-insync-replicas}") int minInsyncReplicas,
                       @Value("${app.kafka.retention-ms}") long retentionMs,
                       @Value("${app.kafka.dlt-retention-ms}") long dltRetentionMs) {
        this.partitions = partitions;
        this.replicationFactor = replicationFactor;
        this.minInsyncReplicas = minInsyncReplicas;
        this.retentionMs = retentionMs;
        this.dltRetentionMs = dltRetentionMs;
    }

    // Set app.kafka.create-topics=false when topics are provisioned by infrastructure automation
    @Bean
    @ConditionalOnProperty(name = "app.kafka.create-topics", havingValue = "true", matchIfMissing = true)
    public KafkaAdmin.NewTopics topics(@Value("${app.topics.food-orders}") String foodOrders,
                                       @Value("${app.topics.food-order-status}") String foodOrderStatus) {
        return new KafkaAdmin.NewTopics(
                topic(foodOrders, retentionMs), topic(dltName(foodOrders), dltRetentionMs),
                topic(foodOrderStatus, retentionMs), topic(dltName(foodOrderStatus), dltRetentionMs));
    }

    // With acks=all, writes need at least min.insync.replicas copies, so one broker can fail when RF=3, minISR=2
    private NewTopic topic(String name, long retention) {
        return TopicBuilder.name(name)
                .partitions(partitions)
                .replicas(replicationFactor)
                .config(TopicConfig.MIN_IN_SYNC_REPLICAS_CONFIG, String.valueOf(minInsyncReplicas))
                .config(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(retention))
                .build();
    }

    private static String dltName(String topic) {
        return topic + "-dlt";
    }

    /**
     * Retries a failed message 3 times with exponential backoff, then moves it to "&lt;topic&gt;-dlt"
     * (the name the topics are created with) so the partition is not blocked.
     */
    @Bean
    public DefaultErrorHandler errorHandler(KafkaTemplate<String, Object> kafkaTemplate,
                                            ProducerFactory<String, Object> producerFactory,
                                            MeterRegistry meterRegistry) {
        // Deserialization failures reach the recoverer as raw bytes, which the JSON serializer cannot republish.
        // Not a bean on purpose: a second KafkaTemplate bean would disable Boot's auto-configured one.
        dltBytesProducerFactory = producerFactory.copyWithConfigurationOverride(
                Map.of("value.serializer", ByteArraySerializer.class));

        Map<Class<?>, KafkaOperations<?, ?>> templates = new LinkedHashMap<>();
        templates.put(byte[].class, new KafkaTemplate<>(dltBytesProducerFactory));
        templates.put(Object.class, kafkaTemplate);

        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(templates,
                // Partition -1 lets the key pick it, so the DLT need not match the source partition count
                (record, ex) -> new TopicPartition(dltName(record.topic()), -1));
        recoverer.setFailIfSendResultIsError(true);

        ExponentialBackOffWithMaxRetries backOff = new ExponentialBackOffWithMaxRetries(3);
        backOff.setInitialInterval(1000L);
        backOff.setMultiplier(2.0);
        backOff.setMaxInterval(10_000L);

        DefaultErrorHandler handler = new DefaultErrorHandler((record, ex) -> {
            log.error("Moving record to DLT: topic={} partition={} offset={} key={}",
                    record.topic(), record.partition(), record.offset(), record.key(), ex);
            meterRegistry.counter("app.kafka.dlt.published", "topic", record.topic()).increment();
            recoverer.accept(record, ex);
        }, backOff);
        handler.addNotRetryableExceptions(IllegalArgumentException.class);
        return handler;
    }

    @Override
    public void destroy() throws Exception {
        if (dltBytesProducerFactory instanceof DisposableBean disposable) {
            disposable.destroy();
        }
    }
}
