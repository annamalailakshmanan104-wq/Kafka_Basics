package com.example.order.event;

import java.math.BigDecimal;

public record FoodItem(String name, int quantity, BigDecimal price) {
}
