package com.example.order.food;

import com.example.order.event.FoodItem;
import com.example.order.event.FoodOrderPlaced;
import com.example.order.event.FoodOrderStatus;
import com.example.order.event.FoodOrderStatusChanged;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class FoodEventProducer {

    private static final Logger log = LoggerFactory.getLogger(FoodEventProducer.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final String ordersTopic;
    private final String statusTopic;
    private final long sendTimeoutMs;

    public FoodEventProducer(KafkaTemplate<String, Object> kafkaTemplate,
                             @Value("${app.topics.food-orders}") String ordersTopic,
                             @Value("${app.topics.food-order-status}") String statusTopic,
                             @Value("${app.kafka.send-timeout-ms}") long sendTimeoutMs) {
        this.kafkaTemplate = kafkaTemplate;
        this.ordersTopic = ordersTopic;
        this.statusTopic = statusTopic;
        this.sendTimeoutMs = sendTimeoutMs;
    }

    public FoodOrderPlaced orderPlaced(String customerName, List<FoodItem> items) {
        BigDecimal total = items.stream()
                .map(item -> item.price().multiply(BigDecimal.valueOf(item.quantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        String orderId = "FO-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        FoodOrderPlaced event = new FoodOrderPlaced(orderId, customerName, items, total, Instant.now());
        send(ordersTopic, orderId, event);
        return event;
    }

    public void statusChanged(String orderId, String customerName, FoodOrderStatus status) {
        send(statusTopic, orderId, new FoodOrderStatusChanged(orderId, customerName, status, Instant.now()));
    }

    // Keyed by orderId so every event of one order lands in the same partition, in order.
    // Waits for the broker ack so a 202 or a committed consumer offset never hides a lost event.
    private void send(String topic, String key, Object event) {
        try {
            var result = kafkaTemplate.send(topic, key, event).get(sendTimeoutMs, TimeUnit.MILLISECONDS);
            log.debug("Sent {} (key {}) to {}-{}@{}", event.getClass().getSimpleName(), key, topic,
                    result.getRecordMetadata().partition(), result.getRecordMetadata().offset());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new EventPublishException("Interrupted while sending to " + topic, e);
        } catch (ExecutionException | TimeoutException e) {
            log.error("Failed to send {} (key {}) to {}", event.getClass().getSimpleName(), key, topic, e);
            throw new EventPublishException("Could not publish to " + topic, e);
        }
    }
}
