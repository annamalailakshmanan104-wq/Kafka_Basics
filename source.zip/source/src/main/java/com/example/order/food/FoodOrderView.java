package com.example.order.food;

import com.example.order.event.FoodItem;
import com.example.order.event.FoodOrderPlaced;
import com.example.order.event.FoodOrderStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record FoodOrderView(
        String orderId,
        String customerName,
        List<FoodItem> items,
        BigDecimal total,
        FoodOrderStatus status,
        Instant placedAt,
        Instant updatedAt) {

    public static FoodOrderView from(FoodOrderPlaced placed) {
        return new FoodOrderView(placed.orderId(), placed.customerName(), placed.items(), placed.total(),
                FoodOrderStatus.PLACED, placed.placedAt(), placed.placedAt());
    }

    public FoodOrderView withStatus(FoodOrderStatus newStatus, Instant at) {
        return new FoodOrderView(orderId, customerName, items, total, newStatus, placedAt, at);
    }
}
