package com.example.order.food;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.List;

public record FoodOrderRequest(
        @NotBlank @Size(max = 50) String customerName,
        @NotEmpty @Size(max = 10) List<@Valid Line> items) {

    public record Line(@NotBlank String name, @Min(1) @Max(20) int quantity) {
    }
}
