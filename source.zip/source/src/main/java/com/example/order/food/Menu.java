package com.example.order.food;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/** Prices live on the server so the client cannot choose its own price. */
@Component
public class Menu {

    public record MenuItem(String name, BigDecimal price, String emoji) {
    }

    private final List<MenuItem> items = List.of(
            new MenuItem("Idli (2 pcs)", new BigDecimal("40"), "🍚"),
            new MenuItem("Masala Dosa", new BigDecimal("80"), "🥞"),
            new MenuItem("Veg Biryani", new BigDecimal("180"), "🍛"),
            new MenuItem("Chicken Biryani", new BigDecimal("240"), "🍗"),
            new MenuItem("Paneer Butter Masala", new BigDecimal("200"), "🧀"),
            new MenuItem("Filter Coffee", new BigDecimal("30"), "☕"));

    private final Map<String, BigDecimal> prices = items.stream()
            .collect(Collectors.toUnmodifiableMap(MenuItem::name, MenuItem::price));

    public List<MenuItem> items() {
        return items;
    }

    public Optional<BigDecimal> priceOf(String name) {
        return Optional.ofNullable(prices.get(name));
    }
}
