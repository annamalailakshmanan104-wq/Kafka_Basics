package com.example.order.event;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record FoodOrderPlaced(
        String orderId,
        String customerName,
        List<FoodItem> items,
        BigDecimal total,
        Instant placedAt) {
}
