package com.example.order.food;

import com.example.order.event.FoodOrderStatus;
import com.example.order.event.FoodOrderStatusChanged;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/** The notification service: turns status events into messages for the user. */
@Component
public class NotificationListener {

    private static final Logger log = LoggerFactory.getLogger(NotificationListener.class);

    private final FoodOrderStore store;
    private final NotificationHub hub;

    public NotificationListener(FoodOrderStore store, NotificationHub hub) {
        this.store = store;
        this.hub = hub;
    }

    @KafkaListener(topics = "${app.topics.food-order-status}", groupId = "notification-service")
    public void onStatusChanged(FoodOrderStatusChanged event) {
        store.advance(event.orderId(), event.status(), event.changedAt()).ifPresent(order -> {
            String message = messageFor(event.status());
            log.info("Notify {}: order {} -> {}", order.customerName(), order.orderId(), message);
            hub.publish(order, message);
        });
    }

    private static String messageFor(FoodOrderStatus status) {
        return switch (status) {
            case PLACED -> "Order sent. Waiting for the restaurant to confirm";
            case RECEIVED -> "Restaurant confirmed your order";
            case PREPARING -> "Your food is being prepared";
            case OUT_FOR_DELIVERY -> "Your order is on the way. Please confirm when it arrives";
            case DELIVERED -> "Delivered. Enjoy your meal!";
        };
    }
}
