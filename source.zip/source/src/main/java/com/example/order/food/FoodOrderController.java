package com.example.order.food;

import com.example.order.event.FoodItem;
import com.example.order.event.FoodOrderPlaced;
import com.example.order.event.FoodOrderStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/food")
public class FoodOrderController {

    private static final int MAX_QUANTITY_PER_ITEM = 20;

    public record StatusUpdateRequest(@NotNull FoodOrderStatus status) {
    }

    private final Menu menu;
    private final FoodEventProducer producer;
    private final FoodOrderStore store;
    private final NotificationHub hub;

    public FoodOrderController(Menu menu, FoodEventProducer producer, FoodOrderStore store, NotificationHub hub) {
        this.menu = menu;
        this.producer = producer;
        this.store = store;
        this.hub = hub;
    }

    @GetMapping("/menu")
    public List<Menu.MenuItem> menu() {
        return menu.items();
    }

    @PostMapping("/orders")
    public ResponseEntity<FoodOrderView> placeOrder(@Valid @RequestBody FoodOrderRequest request) {
        Map<String, Integer> quantities = new LinkedHashMap<>();
        request.items().forEach(line -> quantities.merge(line.name(), line.quantity(), Integer::sum));

        List<FoodItem> items = quantities.entrySet().stream().map(e -> {
            if (e.getValue() > MAX_QUANTITY_PER_ITEM) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Too many of one item");
            }
            return new FoodItem(e.getKey(), e.getValue(), menu.priceOf(e.getKey())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown menu item")));
        }).toList();

        FoodOrderPlaced placed = producer.orderPlaced(request.customerName().trim(), items);
        return ResponseEntity.accepted().body(FoodOrderView.from(placed));
    }

    @GetMapping("/orders")
    public List<FoodOrderView> orders(@RequestParam(required = false) String customer) {
        return store.all(customer);
    }

    @PostMapping("/orders/{orderId}/status")
    public ResponseEntity<Void> updateStatus(@PathVariable String orderId,
                                             @Valid @RequestBody StatusUpdateRequest request) {
        if (request.status() == FoodOrderStatus.DELIVERED) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Delivery is confirmed by the customer");
        }
        FoodOrderView order = store.find(orderId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));
        if (request.status().compareTo(order.status()) <= 0) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Status can only move forward");
        }
        producer.statusChanged(orderId, order.customerName(), request.status());
        return ResponseEntity.accepted().build();
    }

    /** Only the customer who placed the order can confirm that it arrived. */
    @PostMapping("/orders/{orderId}/confirm-delivery")
    public ResponseEntity<Void> confirmDelivery(@PathVariable String orderId, @RequestParam String customer) {
        FoodOrderView order = store.find(orderId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Order not found"));
        if (!order.customerName().equalsIgnoreCase(customer.trim())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not your order");
        }
        if (order.status() != FoodOrderStatus.OUT_FOR_DELIVERY) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Order is not out for delivery");
        }
        producer.statusChanged(orderId, order.customerName(), FoodOrderStatus.DELIVERED);
        return ResponseEntity.accepted().build();
    }

    /** Omit "customer" to get every order (restaurant view). */
    @GetMapping(path = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestParam(required = false) String customer) {
        return hub.subscribe(customer);
    }
}
