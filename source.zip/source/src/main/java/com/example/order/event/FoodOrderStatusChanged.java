package com.example.order.event;

import java.time.Instant;

public record FoodOrderStatusChanged(
        String orderId,
        String customerName,
        FoodOrderStatus status,
        Instant changedAt) {
}
