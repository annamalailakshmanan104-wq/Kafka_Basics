package com.example.order.event;

/** Declaration order is the lifecycle order; status may only move forward. */
public enum FoodOrderStatus {
    PLACED,
    RECEIVED,
    PREPARING,
    OUT_FOR_DELIVERY,
    DELIVERED
}
