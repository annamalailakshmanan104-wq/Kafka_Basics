package com.example.order.food;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/** Kafka did not acknowledge an event; callers see 503 and listeners retry / dead-letter. */
@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
public class EventPublishException extends RuntimeException {

    public EventPublishException(String message, Throwable cause) {
        super(message, cause);
    }
}
