package com.example.order.food;

import jakarta.annotation.PreDestroy;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pushes order updates to open browser tabs over Server-Sent Events. */
@Component
public class NotificationHub {

    public record OrderNotification(FoodOrderView order, String message) {
    }

    /** customer == null means "restaurant": receives every order. */
    private record Subscriber(SseEmitter emitter, String customer) {
        boolean wants(FoodOrderView order) {
            return customer == null || customer.equalsIgnoreCase(order.customerName());
        }
    }

    private final List<Subscriber> subscribers = new CopyOnWriteArrayList<>();
    // One sender thread keeps events in order and stops a slow browser from blocking Kafka listener threads
    private final ExecutorService sender = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "sse-sender");
        thread.setDaemon(true);
        return thread;
    });

    public SseEmitter subscribe(String customer) {
        SseEmitter emitter = new SseEmitter(Duration.ofMinutes(30).toMillis());
        Subscriber subscriber = new Subscriber(emitter,
                customer == null || customer.isBlank() ? null : customer.trim());
        subscribers.add(subscriber);
        emitter.onCompletion(() -> subscribers.remove(subscriber));
        emitter.onTimeout(() -> subscribers.remove(subscriber));
        emitter.onError(ex -> subscribers.remove(subscriber));
        return emitter;
    }

    public void publish(FoodOrderView order, String message) {
        OrderNotification notification = new OrderNotification(order, message);
        sender.execute(() -> subscribers.stream()
                .filter(s -> s.wants(order))
                .forEach(s -> send(s, SseEmitter.event().name("order").data(notification))));
    }

    // Idle connections are dropped by some proxies; a comment line keeps them open and is ignored by the browser
    @Scheduled(fixedRate = 20_000)
    void heartbeat() {
        sender.execute(() -> subscribers.forEach(s -> send(s, SseEmitter.event().comment("ping"))));
    }

    private void send(Subscriber s, SseEmitter.SseEventBuilder event) {
        try {
            s.emitter().send(event);
        } catch (IOException | IllegalStateException ex) {
            // The browser went away and the container already ended this connection. Completing it again
            // would throw, so only drop the subscriber and keep serving the others.
            subscribers.remove(s);
        }
    }

    @PreDestroy
    void shutdown() {
        sender.shutdownNow();
    }
}
