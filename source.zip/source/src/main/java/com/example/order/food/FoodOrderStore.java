package com.example.order.food;

import com.example.order.event.FoodOrderStatus;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/** In-memory only: orders are lost on restart. Swap for a database in a real system. */
@Component
public class FoodOrderStore {

    private final Map<String, FoodOrderView> orders = new ConcurrentHashMap<>();

    /** putIfAbsent so a redelivered "placed" event cannot reset a later status. Returns true only for a new order. */
    public boolean saveNew(FoodOrderView order) {
        return orders.putIfAbsent(order.orderId(), order) == null;
    }

    /** Returns the updated order only if the status actually moved forward. */
    public Optional<FoodOrderView> advance(String orderId, FoodOrderStatus status, Instant at) {
        AtomicReference<FoodOrderView> changed = new AtomicReference<>();
        orders.computeIfPresent(orderId, (id, current) -> {
            if (status.compareTo(current.status()) <= 0) {
                return current;
            }
            FoodOrderView updated = current.withStatus(status, at);
            changed.set(updated);
            return updated;
        });
        return Optional.ofNullable(changed.get());
    }

    public Optional<FoodOrderView> find(String orderId) {
        return Optional.ofNullable(orders.get(orderId));
    }

    public List<FoodOrderView> all(String customer) {
        return orders.values().stream()
                .filter(o -> customer == null || customer.isBlank() || o.customerName().equalsIgnoreCase(customer.trim()))
                .sorted(Comparator.comparing(FoodOrderView::placedAt))
                .toList();
    }
}
