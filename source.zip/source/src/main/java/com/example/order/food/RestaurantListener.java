package com.example.order.food;

import com.example.order.event.FoodOrderPlaced;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/** The restaurant: receives new orders from Kafka and alerts the restaurant, which must confirm each one. */
@Component
public class RestaurantListener {

    private static final Logger log = LoggerFactory.getLogger(RestaurantListener.class);

    private final FoodOrderStore store;
    private final NotificationHub hub;

    public RestaurantListener(FoodOrderStore store, NotificationHub hub) {
        this.store = store;
        this.hub = hub;
    }

    @KafkaListener(topics = "${app.topics.food-orders}", groupId = "restaurant-service")
    public void onOrderPlaced(FoodOrderPlaced order) {
        log.info("Restaurant received {} from {}: {} item(s), total {}",
                order.orderId(), order.customerName(), order.items().size(), order.total());
        FoodOrderView view = FoodOrderView.from(order);
        // A redelivered event must not alert the restaurant twice
        if (store.saveNew(view)) {
            hub.publish(view, "Waiting for the restaurant to confirm your order");
        }
    }
}
