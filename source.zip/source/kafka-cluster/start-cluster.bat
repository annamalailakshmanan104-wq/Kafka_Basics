@echo off
rem Starts 3 Kafka nodes, each in its own window. Close a window to simulate a broker failure.
set KAFKA_HOME=D:\09_Applications\kafka\kafka_2.13-4.4.0

start "kafka-node-1 (9092)" cmd /k ""%KAFKA_HOME%\bin\windows\kafka-server-start.bat" "%~dp0node-1.properties""
start "kafka-node-2 (9094)" cmd /k ""%KAFKA_HOME%\bin\windows\kafka-server-start.bat" "%~dp0node-2.properties""
start "kafka-node-3 (9096)" cmd /k ""%KAFKA_HOME%\bin\windows\kafka-server-start.bat" "%~dp0node-3.properties""
