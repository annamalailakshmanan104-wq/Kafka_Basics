@echo off
rem One-time: formats storage of all 3 nodes with the same cluster ID.
rem Change KAFKA_HOME if Kafka is installed elsewhere.
set KAFKA_HOME=D:\09_Applications\kafka\kafka_2.13-4.4.0

for /f %%i in ('"%KAFKA_HOME%\bin\windows\kafka-storage.bat" random-uuid 2^>nul') do set CLUSTER_ID=%%i
echo Cluster ID: %CLUSTER_ID%

call "%KAFKA_HOME%\bin\windows\kafka-storage.bat" format -t %CLUSTER_ID% -c "%~dp0node-1.properties"
call "%KAFKA_HOME%\bin\windows\kafka-storage.bat" format -t %CLUSTER_ID% -c "%~dp0node-2.properties"
call "%KAFKA_HOME%\bin\windows\kafka-storage.bat" format -t %CLUSTER_ID% -c "%~dp0node-3.properties"
echo Done. Now run start-cluster.bat
